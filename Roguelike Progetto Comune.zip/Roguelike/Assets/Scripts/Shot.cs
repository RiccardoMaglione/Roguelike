﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Shot : MonoBehaviour
{
    public float velocity = 10f; //velocità proiettile
    public Vector3 direction = Vector3.forward; //direzione proiettile
    private void OnCollisionEnter(Collision collision) //rileva una collisione
    {
        if (collision.gameObject.tag == "Enemy") //se collide con un oggetto che ha come tag limit
        {
            Destroy(collision.collider.gameObject);
            Die(); //muore
        }
    }
    void Die()
    {
        Destroy(this.gameObject); //distrugge se stesso
    }
    void Move()
    {
        transform.Translate(direction * velocity * Time.deltaTime * 2); //codice per il movimento
    }

    void Update()
    {
        Move();
    }
}