﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Score : MonoBehaviour
{
    float time = 0.0f;
    public Text text;

    void Update()
    {
        time += Time.deltaTime;
        text.text = "Score: " + Mathf.Round(time);
    }
}
