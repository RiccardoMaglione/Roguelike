﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Rune : MonoBehaviour
{
    public GameObject player;
    public GameObject rune1;
    public GameObject rune3;
    public GameObject backpack;


    // Start is called before the first frame update
    void Start()
    {
        rune3.SetActive(false);
    }

    // Update is called once per frame
    void Update()
    {
        if(Input.GetKeyDown(KeyCode.O))
        {
            rune1.SetActive(false);
            rune3.transform.parent = player.transform;
            rune1.transform.parent = backpack.transform;
            rune3.transform.position = player.transform.position;
            rune3.transform.rotation = player.transform.rotation;
            rune3.SetActive(true);
        }
        if (Input.GetKeyDown(KeyCode.I))
        {
            rune3.SetActive(false);
            rune1.transform.parent = player.transform;
            rune3.transform.parent = backpack.transform;
            rune1.transform.position = player.transform.position;
            rune1.transform.rotation = player.transform.rotation;
            rune1.SetActive(true);
        }

    }
}
