﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class PlayerShot: MonoBehaviour
{
    public GameObject shotReference;
    public GameObject shotPunto;

    void Shot()
    {

        GameObject newShot = Instantiate(shotReference, shotPunto.transform.position, transform.localRotation); //instanzia l'oggetto
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space)) Shot(); //spara
    }
}