﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Timer : MonoBehaviour
{
    float time = 0.0f;
    public Text text;

    void Update()
    {
        time += Time.deltaTime;
        text.text = "Timer: " + Mathf.Round(time);
    }
}
