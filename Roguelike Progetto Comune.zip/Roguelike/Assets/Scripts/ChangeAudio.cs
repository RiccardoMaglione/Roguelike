﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


public class ChangeAudio : MonoBehaviour
{
    AudioSource source;
    public float musicVolume=1f;
    public Slider musicSlider;
    
   
    private void Awake()
    {
        musicVolume = PlayerPrefs.GetFloat("MusicVolume");
        source = GameObject.FindWithTag("Music").GetComponent<AudioSource>();
        musicSlider.value=musicVolume;
    }

    public void ChangeVolume(float volume)
    {
        musicVolume = volume;
        PlayerPrefs.SetFloat("MusicVolume", musicVolume);
    }

    void Start()
    {
        
    }

    void Update()
    {
        source.volume = musicVolume; 
    }
}
