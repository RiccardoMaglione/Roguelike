﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ShotDifferentEnemy : MonoBehaviour
{

    public Transform player;
    public float range = 50.0f;
    public float bulletImpulse = 20.0f;
    private bool onRange = false;
    public Rigidbody projectile;
    Quaternion RotBullet1;
    Quaternion RotBullet3;

    void Start()
    {
        float rand = Random.Range(1.0f, 2.0f);
        InvokeRepeating("Shoot", 2, rand);
    }

    void Shoot()
    {
        if (onRange)
        {
            RotBullet1 = Quaternion.Euler(0, 30, 0);
            RotBullet3 = Quaternion.Euler(0, -30, 0);
            Rigidbody bullet1 = (Rigidbody)Instantiate(projectile, transform.position + new Vector3((float)0.5, 0, 0) + transform.forward, transform.rotation * RotBullet1);
            Rigidbody bullet2 = (Rigidbody)Instantiate(projectile, transform.position + new Vector3(0, 0, 0) + transform.forward, transform.rotation);
            Rigidbody bullet3 = (Rigidbody)Instantiate(projectile, transform.position + new Vector3((float)-0.5, 0, 0) + transform.forward, transform.rotation * RotBullet3);
            bullet1.AddForce(transform.forward * bulletImpulse, ForceMode.Impulse);
            bullet2.AddForce(transform.forward * bulletImpulse, ForceMode.Impulse);
            bullet3.AddForce(transform.forward * bulletImpulse, ForceMode.Impulse);

            Destroy(bullet1.gameObject, 2);
            Destroy(bullet2.gameObject, 2);
            Destroy(bullet3.gameObject, 2);
        }
    }

    void Update()
    {
        onRange = Vector3.Distance(transform.position, player.position) < range;
        if (onRange)
            transform.LookAt(player);
    }
}
