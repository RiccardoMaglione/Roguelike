﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Slime : MonoBehaviour
{
    private Transform target;
    private float speed = 1f;
    private Vector3 speedRot = Vector3.right * 50f;

    void Start()
    {
        target = GameObject.FindGameObjectWithTag("Personaggio").transform;
    }

    private void MoveSlime()
    {
        transform.Rotate(speedRot * Time.deltaTime);
        transform.position = Vector3.MoveTowards(transform.position, target.position, speed * Time.deltaTime);
    }

    void Update()
    {
        MoveSlime();
    }
}