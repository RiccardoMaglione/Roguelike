﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Boss : MonoBehaviour
{
    public GameObject player;
    public GameObject rune1;
    public GameObject rune3;
    public GameObject backpack;
    // Start is called before the first frame update
    void Start()
    {
        rune3.SetActive(false);
    }

    // Update is called once per frame
    void Update()
    {
        if (GameObject.FindGameObjectsWithTag("Boss").Length == 0)
        {
            rune1.SetActive(false);
            rune3.transform.parent = player.transform;
            rune1.transform.parent = backpack.transform;
            rune3.transform.position = player.transform.position;
            rune3.transform.rotation = player.transform.rotation;
            rune3.SetActive(true);
        }
    }
}
